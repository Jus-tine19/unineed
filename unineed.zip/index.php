<?php
// Root index: load the login page kept in config/index.php
// This keeps the friendly URL /unineeds/ while reusing the login implementation
require_once __DIR__ . '/config/index.php';
